//! Full TUI renderer using ratatui + crossterm.
//!
//! Implements `tui_menu` which sets up alternate screen + raw mode,
//! renders an interactive menu, and returns a TerminalResponse.
//! Always restores terminal on exit via RAII guard.

use crossterm::{
    event::{self, Event, KeyCode, KeyEventKind},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use ratatui::{
    backend::CrosstermBackend,
    layout::{Constraint, Direction, Layout, Rect},
    style::{Color, Modifier, Style},
    text::{Line, Span},
    widgets::{Block, Borders, List, ListItem, ListState, Paragraph, Wrap},
    Terminal,
};
use std::io::{stderr, Write};

use crate::{
    renderer::TerminalResponse,
    schema::{CommentMode, InteractionOption, InteractionRequest, ResponseStatus},
    terminal::TerminalCapabilities,
};

// ─── Error type ─────────────────────────────────────────────────────────────

#[derive(Debug)]
pub enum TuiError {
    Io(std::io::Error),
    TerminalSetup(String),
}

impl std::fmt::Display for TuiError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TuiError::Io(e) => write!(f, "IO error: {e}"),
            TuiError::TerminalSetup(s) => write!(f, "Terminal setup error: {s}"),
        }
    }
}

impl From<std::io::Error> for TuiError {
    fn from(e: std::io::Error) -> Self {
        TuiError::Io(e)
    }
}

// ─── RAII terminal guard ─────────────────────────────────────────────────────

struct TerminalGuard;

impl Drop for TerminalGuard {
    fn drop(&mut self) {
        let _ = disable_raw_mode();
        let _ = execute!(stderr(), LeaveAlternateScreen);
    }
}

// ─── TUI state machine ───────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq)]
pub enum TuiAction {
    SelectUp,
    SelectDown,
    Confirm,
    Cancel,
    NumberKey(usize), // 1-based index
    CommentChar(char),
    CommentBackspace,
    None,
}

/// Internal state for the TUI menu.
pub struct TuiMenuState {
    pub selected_index: usize,
    pub option_count: usize,
    pub comment: String,
    pub comment_mode: CommentMode,
    pub confirmed: bool,
    pub cancelled: bool,
}

impl TuiMenuState {
    pub fn new(option_count: usize, comment_mode: CommentMode) -> Self {
        Self {
            selected_index: 0,
            option_count,
            comment: String::new(),
            comment_mode,
            confirmed: false,
            cancelled: false,
        }
    }

    /// Apply a TuiAction to this state. Returns true if terminal should stop.
    pub fn apply(&mut self, action: TuiAction) -> bool {
        match action {
            TuiAction::SelectUp => {
                if self.selected_index > 0 {
                    self.selected_index -= 1;
                }
                false
            }
            TuiAction::SelectDown => {
                if self.selected_index + 1 < self.option_count {
                    self.selected_index += 1;
                }
                false
            }
            TuiAction::NumberKey(n) => {
                // 1-based; clamp to valid range
                if n >= 1 && n <= self.option_count {
                    self.selected_index = n - 1;
                }
                false
            }
            TuiAction::Confirm => {
                self.confirmed = true;
                true
            }
            TuiAction::Cancel => {
                self.cancelled = true;
                true
            }
            TuiAction::CommentChar(c) => {
                self.comment.push(c);
                false
            }
            TuiAction::CommentBackspace => {
                self.comment.pop();
                false
            }
            TuiAction::None => false,
        }
    }
}

/// Map a crossterm KeyCode to a TuiAction.
pub fn key_to_action(key: KeyCode, comment_active: bool) -> TuiAction {
    if comment_active {
        return match key {
            KeyCode::Enter => TuiAction::Confirm,
            KeyCode::Esc => TuiAction::Cancel,
            KeyCode::Char(c) => TuiAction::CommentChar(c),
            KeyCode::Backspace => TuiAction::CommentBackspace,
            _ => TuiAction::None,
        };
    }
    match key {
        KeyCode::Up | KeyCode::Char('k') => TuiAction::SelectUp,
        KeyCode::Down | KeyCode::Char('j') => TuiAction::SelectDown,
        KeyCode::Enter => TuiAction::Confirm,
        KeyCode::Char('q') | KeyCode::Esc => TuiAction::Cancel,
        KeyCode::Char(c) if c.is_ascii_digit() => {
            let n = c as usize - '0' as usize;
            TuiAction::NumberKey(n)
        }
        _ => TuiAction::None,
    }
}

// ─── Render frame ────────────────────────────────────────────────────────────

fn render_frame(
    terminal: &mut Terminal<CrosstermBackend<std::io::Stderr>>,
    request: &InteractionRequest,
    options: &[InteractionOption],
    state: &TuiMenuState,
) -> Result<(), TuiError> {
    terminal.draw(|frame| {
        let area = frame.area();
        let needs_comment = !matches!(state.comment_mode, CommentMode::Disabled);

        // Layout: title | message | options list | [comment box] | hints
        let constraints = if needs_comment {
            vec![
                Constraint::Length(3),  // title bar
                Constraint::Length(4),  // message
                Constraint::Min(4),     // options
                Constraint::Length(3),  // comment box
                Constraint::Length(1),  // hints
            ]
        } else {
            vec![
                Constraint::Length(3),
                Constraint::Length(4),
                Constraint::Min(4),
                Constraint::Length(1),
            ]
        };

        let chunks = Layout::default()
            .direction(Direction::Vertical)
            .constraints(constraints)
            .split(area);

        // ── Title bar ──
        let title = Paragraph::new(request.title.as_str())
            .block(Block::default().borders(Borders::ALL).title("sy-interact"))
            .style(Style::default().fg(Color::Cyan).add_modifier(Modifier::BOLD));
        frame.render_widget(title, chunks[0]);

        // ── Message ──
        let msg = Paragraph::new(request.message.as_str())
            .block(Block::default().borders(Borders::ALL))
            .wrap(Wrap { trim: true });
        frame.render_widget(msg, chunks[1]);

        // ── Options list ──
        let items: Vec<ListItem> = options
            .iter()
            .enumerate()
            .map(|(i, opt)| {
                let rec = if opt.recommended { " ✓" } else { "  " };
                let sc = opt
                    .shortcut
                    .as_deref()
                    .map(|s| format!("[{}] ", s))
                    .unwrap_or_default();
                let label = format!("{}{}. {}{}{}", sc, i + 1, opt.label, rec, "");
                ListItem::new(Line::from(vec![Span::raw(label)]))
            })
            .collect();

        let mut list_state = ListState::default();
        list_state.select(Some(state.selected_index));

        let list = List::new(items)
            .block(Block::default().borders(Borders::ALL).title("选项"))
            .highlight_style(
                Style::default()
                    .bg(Color::Blue)
                    .fg(Color::White)
                    .add_modifier(Modifier::BOLD),
            )
            .highlight_symbol("► ");
        frame.render_stateful_widget(list, chunks[2], &mut list_state);

        // ── Comment box (if enabled) ──
        if needs_comment {
            let comment_title = match state.comment_mode {
                CommentMode::Required => "备注（必填）",
                _ => "备注（可选）",
            };
            let comment_widget = Paragraph::new(state.comment.as_str())
                .block(Block::default().borders(Borders::ALL).title(comment_title))
                .style(Style::default().fg(Color::Yellow));
            frame.render_widget(comment_widget, chunks[3]);
        }

        // ── Key hints ──
        let hint_idx = if needs_comment { 4 } else { 3 };
        if hint_idx < chunks.len() {
            let hints = Paragraph::new("↑↓/jk 移动  Enter 确认  q/Esc 取消  1-9 快速选择")
                .style(Style::default().fg(Color::DarkGray));
            frame.render_widget(hints, chunks[hint_idx]);
        }
    })?;
    Ok(())
}

// ─── Public API ──────────────────────────────────────────────────────────────

/// Run the full TUI menu.
/// Sets up alternate screen + raw mode, renders interactively,
/// always restores terminal via RAII guard.
pub fn tui_menu(
    request: &InteractionRequest,
    _caps: &TerminalCapabilities,
) -> Result<TerminalResponse, TuiError> {
    let options = request.options.clone();
    let option_count = options.len();

    // Setup terminal
    enable_raw_mode().map_err(|e| TuiError::TerminalSetup(e.to_string()))?;
    execute!(stderr(), EnterAlternateScreen)
        .map_err(|e| TuiError::TerminalSetup(e.to_string()))?;

    // RAII guard — restores terminal even on panic
    let _guard = TerminalGuard;

    let backend = CrosstermBackend::new(stderr());
    let mut terminal = Terminal::new(backend)?;

    let mut state = TuiMenuState::new(option_count, request.comment_mode.clone());

    loop {
        render_frame(&mut terminal, request, &options, &state)?;

        if let Event::Key(key) = event::read()? {
            if key.kind != KeyEventKind::Press {
                continue;
            }
            let comment_active = !matches!(state.comment_mode, CommentMode::Disabled);
            let action = key_to_action(key.code, comment_active);
            let done = state.apply(action);
            if done {
                break;
            }
        }
    }

    if state.cancelled {
        return Ok(TerminalResponse::cancelled("tui"));
    }

    let selected_option = options
        .get(state.selected_index)
        .map(|o| o.id.clone())
        .unwrap_or_default();

    Ok(TerminalResponse {
        status: ResponseStatus::Completed,
        selected_option_ids: vec![selected_option],
        comment: if state.comment.is_empty() { None } else { Some(state.comment.clone()) },
        presenter_mode: "tui".to_string(),
    })
}

// ─── Tests ───────────────────────────────────────────────────────────────────

#[cfg(test)]
mod interaction_tui {
    use super::*;
    use crate::schema::CommentMode;

    fn make_state(count: usize) -> TuiMenuState {
        TuiMenuState::new(count, CommentMode::Disabled)
    }

    #[test]
    fn test_initial_selection_is_zero() {
        let s = make_state(3);
        assert_eq!(s.selected_index, 0);
        assert!(!s.confirmed);
        assert!(!s.cancelled);
    }

    #[test]
    fn test_select_down_moves_index() {
        let mut s = make_state(3);
        s.apply(TuiAction::SelectDown);
        assert_eq!(s.selected_index, 1);
    }

    #[test]
    fn test_select_up_does_not_go_below_zero() {
        let mut s = make_state(3);
        s.apply(TuiAction::SelectUp);
        assert_eq!(s.selected_index, 0);
    }

    #[test]
    fn test_select_down_does_not_go_past_end() {
        let mut s = make_state(2);
        s.apply(TuiAction::SelectDown);
        s.apply(TuiAction::SelectDown);
        assert_eq!(s.selected_index, 1);
    }

    #[test]
    fn test_number_key_selects_correct_index() {
        let mut s = make_state(3);
        let done = s.apply(TuiAction::NumberKey(2));
        assert_eq!(s.selected_index, 1);
        assert!(!done);
    }

    #[test]
    fn test_number_key_out_of_range_is_ignored() {
        let mut s = make_state(2);
        s.apply(TuiAction::NumberKey(5));
        assert_eq!(s.selected_index, 0);
    }

    #[test]
    fn test_confirm_sets_confirmed_and_returns_true() {
        let mut s = make_state(2);
        let done = s.apply(TuiAction::Confirm);
        assert!(s.confirmed);
        assert!(done);
    }

    #[test]
    fn test_cancel_sets_cancelled_and_returns_true() {
        let mut s = make_state(2);
        let done = s.apply(TuiAction::Cancel);
        assert!(s.cancelled);
        assert!(done);
    }

    #[test]
    fn test_comment_char_appended() {
        let mut s = TuiMenuState::new(2, CommentMode::Optional);
        s.apply(TuiAction::CommentChar('H'));
        s.apply(TuiAction::CommentChar('i'));
        assert_eq!(s.comment, "Hi");
    }

    #[test]
    fn test_comment_backspace() {
        let mut s = TuiMenuState::new(2, CommentMode::Optional);
        s.apply(TuiAction::CommentChar('A'));
        s.apply(TuiAction::CommentBackspace);
        assert_eq!(s.comment, "");
    }

    #[test]
    fn test_key_to_action_up() {
        assert_eq!(key_to_action(KeyCode::Up, false), TuiAction::SelectUp);
        assert_eq!(key_to_action(KeyCode::Char('k'), false), TuiAction::SelectUp);
    }

    #[test]
    fn test_key_to_action_down() {
        assert_eq!(key_to_action(KeyCode::Down, false), TuiAction::SelectDown);
        assert_eq!(key_to_action(KeyCode::Char('j'), false), TuiAction::SelectDown);
    }

    #[test]
    fn test_key_to_action_cancel() {
        assert_eq!(key_to_action(KeyCode::Char('q'), false), TuiAction::Cancel);
        assert_eq!(key_to_action(KeyCode::Esc, false), TuiAction::Cancel);
    }

    #[test]
    fn test_key_to_action_number() {
        assert_eq!(key_to_action(KeyCode::Char('1'), false), TuiAction::NumberKey(1));
        assert_eq!(key_to_action(KeyCode::Char('3'), false), TuiAction::NumberKey(3));
    }

    #[test]
    fn test_key_to_action_comment_mode_routes_chars() {
        // In comment_active mode, chars go to CommentChar
        assert_eq!(key_to_action(KeyCode::Char('a'), true), TuiAction::CommentChar('a'));
        assert_eq!(key_to_action(KeyCode::Backspace, true), TuiAction::CommentBackspace);
    }

    #[test]
    fn test_state_machine_full_confirm_flow() {
        let mut s = make_state(3);
        s.apply(TuiAction::SelectDown); // index=1
        s.apply(TuiAction::SelectDown); // index=2
        s.apply(TuiAction::SelectUp);   // index=1
        let done = s.apply(TuiAction::Confirm);
        assert!(done);
        assert_eq!(s.selected_index, 1);
        assert!(s.confirmed);
        assert!(!s.cancelled);
    }

    #[test]
    fn test_state_machine_cancel_flow() {
        let mut s = make_state(3);
        s.apply(TuiAction::SelectDown);
        let done = s.apply(TuiAction::Cancel);
        assert!(done);
        assert!(s.cancelled);
        assert!(!s.confirmed);
    }
}
