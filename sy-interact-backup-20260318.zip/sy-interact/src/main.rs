// sy-interact: presenter-only interaction renderer for seeyue-workflows
//
// This binary is a PRESENTER ONLY — no workflow logic, no policy decisions.
// It reads interaction requests from file, renders them to the terminal,
// and writes structured responses back to file.
//
// Exit codes:
//   0 = success (response written)
//   1 = process error (bad args, missing file, IO error)
//   2 = user cancelled
//   3 = timeout
//
// See docs/sy-interact-cli-spec.md for the CLI contract.
// See workflow/interaction.schema.yaml for the data schema.

mod schema;
mod io;
mod terminal;
mod renderer;
mod tui;

use clap::{Parser, Subcommand};
use schema::{InteractionResponse, ResponseStatus};
use std::path::PathBuf;

// ─── Exit codes ────────────────────────────────────────────────────────────

const EXIT_SUCCESS: i32 = 0;
const EXIT_PROCESS_ERROR: i32 = 1;
const EXIT_USER_CANCEL: i32 = 2;
const EXIT_TIMEOUT: i32 = 3;

// ─── CLI definition ────────────────────────────────────────────────────────

#[derive(Parser)]
#[command(
    name = "sy-interact",
    version,
    about = "Presenter-only interaction renderer for seeyue-workflows",
    long_about = None
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Read a request file, render interaction, write response file
    Render {
        /// Path to the interaction request JSON file
        #[arg(long = "request-file", value_name = "PATH")]
        request_file: PathBuf,

        /// Path to write the interaction response JSON file
        #[arg(long = "response-file", value_name = "PATH")]
        response_file: PathBuf,

        /// Rendering mode: auto, tui, text, plain
        #[arg(long, default_value = "auto")]
        mode: String,

        /// Color mode: auto, always, never
        #[arg(long, default_value = "auto")]
        color: String,

        /// Timeout in seconds (0 = no timeout)
        #[arg(long, default_value = "0")]
        timeout_seconds: u32,
    },
    /// Probe terminal capabilities and output result
    ProbeTerminal {
        /// Output as JSON (default: true)
        #[arg(long, default_value = "false")]
        json: bool,

        /// Output format: json or text (overridden by --json flag)
        #[arg(long, default_value = "json")]
        format: String,
    },
}

// ─── Entry point ───────────────────────────────────────────────────────────

fn main() {
    let cli = Cli::parse();
    let code = run(cli);
    std::process::exit(code);
}

fn run(cli: Cli) -> i32 {
    match cli.command {
        Commands::ProbeTerminal { format, json } => {
            let effective_format = if json { "json" } else { format.as_str() };
            cmd_probe_terminal(effective_format)
        }
        Commands::Render {
            request_file,
            response_file,
            mode,
            color: _color,
            timeout_seconds,
        } => cmd_render(&request_file, &response_file, &mode, timeout_seconds),
    }
}

// ─── probe-terminal ────────────────────────────────────────────────────────

fn cmd_probe_terminal(format: &str) -> i32 {
    let caps = terminal::probe_terminal();
    match format {
        "json" => {
            match serde_json::to_string_pretty(&caps) {
                Ok(json) => {
                    println!("{json}");
                    EXIT_SUCCESS
                }
                Err(e) => {
                    eprintln!("[sy-interact] error serializing terminal caps: {e}");
                    EXIT_PROCESS_ERROR
                }
            }
        }
        "text" => {
            println!("is_tty: {}", caps.is_tty);
            println!("color_depth: {:?}", caps.color_depth);
            println!("columns: {}", caps.columns);
            println!("rows: {}", caps.rows);
            println!("ansi_enabled: {}", caps.ansi_enabled);
            println!("supports_raw_mode: {}", caps.supports_raw_mode);
            println!("supports_alternate_screen: {}", caps.supports_alternate_screen);
            println!("preferred_mode: {}", caps.preferred_mode);
            EXIT_SUCCESS
        }
        other => {
            eprintln!("[sy-interact] unknown format: {other}. Use json or text.");
            EXIT_PROCESS_ERROR
        }
    }
}

// ─── render ────────────────────────────────────────────────────────────────

fn cmd_render(
    request_file: &std::path::Path,
    response_file: &std::path::Path,
    mode: &str,
    _timeout_seconds: u32,
) -> i32 {
    // 1. Read request
    let request = match io::read_request(request_file) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("[sy-interact] failed to read request: {e}");
            return EXIT_PROCESS_ERROR;
        }
    };

    // 2. Probe terminal
    let caps = terminal::probe_terminal();

    // 3. Select renderer
    let effective_mode = if mode == "auto" {
        caps.preferred_mode.as_str()
    } else {
        mode
    };

    // 4. Render
    let options = request.options.clone();
    let terminal_response = match effective_mode {
        "plain" => {
            let mut stdin = std::io::BufReader::new(std::io::stdin());
            let mut stderr = std::io::stderr();
            renderer::plain_prompt(&request, &mut stdin, &mut stderr)
        }
        "tui" => {
            match tui::tui_menu(&request, &caps) {
                Ok(resp) => resp,
                Err(e) => {
                    eprintln!("[sy-interact] TUI error: {e}, falling back to text_menu");
                    let mut stdin = std::io::BufReader::new(std::io::stdin());
                    let mut stderr = std::io::stderr();
                    renderer::text_menu(&request, &options, &mut stdin, &mut stderr)
                }
            }
        }
        _ => {
            // "text" or unrecognised mode
            let mut stdin = std::io::BufReader::new(std::io::stdin());
            let mut stderr = std::io::stderr();
            renderer::text_menu(&request, &options, &mut stdin, &mut stderr)
        }
    };

    // 5. Convert TerminalResponse → InteractionResponse
    let mut response = InteractionResponse::new(&request.interaction_id, terminal_response.status.clone());
    response.selected_option_ids = terminal_response.selected_option_ids;
    response.comment = terminal_response.comment;
    response.presenter_mode_used = Some(terminal_response.presenter_mode);

    // 6. Write response file
    if let Err(e) = io::write_response(response_file, &response) {
        eprintln!("[sy-interact] failed to write response: {e}");
        return EXIT_PROCESS_ERROR;
    }

    // 7. Exit code reflects user action
    match response.status {
        ResponseStatus::Completed => EXIT_SUCCESS,
        ResponseStatus::Cancelled => EXIT_USER_CANCEL,
        ResponseStatus::TimedOut => EXIT_TIMEOUT,
        ResponseStatus::Error => EXIT_PROCESS_ERROR,
    }
}

// ─── Tests ─────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use schema::{
        ColorProfile, CommentMode, InteractionKind, InteractionOption, InteractionStatus,
        PresentationHints, PresentationMode, SelectionMode,
    };
    use tempfile::tempdir;

    fn write_sample_request(path: &std::path::Path) {
        let req = schema::InteractionRequest {
            schema: 1,
            interaction_id: "ix-20260318-001".to_string(),
            kind: InteractionKind::ApprovalRequest,
            status: InteractionStatus::Pending,
            title: "Test Title".to_string(),
            message: "Test message".to_string(),
            selection_mode: SelectionMode::SingleSelect,
            options: vec![
                InteractionOption {
                    id: "approve".to_string(),
                    label: "Approve".to_string(),
                    description: None,
                    recommended: true,
                    destructive: false,
                    shortcut: Some("y".to_string()),
                },
                InteractionOption {
                    id: "deny".to_string(),
                    label: "Deny".to_string(),
                    description: None,
                    recommended: false,
                    destructive: false,
                    shortcut: Some("n".to_string()),
                },
            ],
            comment_mode: CommentMode::Disabled,
            presentation: PresentationHints {
                mode: PresentationMode::TextMenu,
                color_profile: Some(ColorProfile::Auto),
                theme: None,
            },
            originating_request_id: "req-001".to_string(),
            created_at: "2026-03-18T00:00:00Z".to_string(),
            risk_level: None,
            timeout_seconds: None,
            scope: None,
        };
        let json = serde_json::to_string_pretty(&req).unwrap();
        std::fs::write(path, json).unwrap();
    }

    #[test]
    fn test_probe_terminal_json_returns_success() {
        // cmd_probe_terminal should return EXIT_SUCCESS and output valid JSON
        // We can't capture stdout easily in unit tests, but we verify exit code
        let code = cmd_probe_terminal("json");
        assert_eq!(code, EXIT_SUCCESS);
    }

    #[test]
    fn test_probe_terminal_text_returns_success() {
        let code = cmd_probe_terminal("text");
        assert_eq!(code, EXIT_SUCCESS);
    }

    #[test]
    fn test_probe_terminal_unknown_format_returns_error() {
        let code = cmd_probe_terminal("xml");
        assert_eq!(code, EXIT_PROCESS_ERROR);
    }

    #[test]
    fn test_render_missing_request_file_returns_process_error() {
        let dir = tempdir().unwrap();
        let req_path = dir.path().join("nonexistent.json");
        let resp_path = dir.path().join("response.json");
        let code = cmd_render(&req_path, &resp_path, "plain", 0);
        assert_eq!(code, EXIT_PROCESS_ERROR);
    }

    #[test]
    fn test_exit_code_constants() {
        assert_eq!(EXIT_SUCCESS, 0);
        assert_eq!(EXIT_PROCESS_ERROR, 1);
        assert_eq!(EXIT_USER_CANCEL, 2);
        assert_eq!(EXIT_TIMEOUT, 3);
    }

    #[test]
    fn test_render_with_valid_request_and_stdin() {
        // Write a request file, simulate stdin input via test harness
        // Since cmd_render reads from real stdin we test the IO layer separately;
        // here we just verify the request file is read successfully
        let dir = tempdir().unwrap();
        let req_path = dir.path().join("req.json");
        write_sample_request(&req_path);
        let req = io::read_request(&req_path).unwrap();
        assert_eq!(req.interaction_id, "ix-20260318-001");
        assert_eq!(req.schema, 1);
    }
}
