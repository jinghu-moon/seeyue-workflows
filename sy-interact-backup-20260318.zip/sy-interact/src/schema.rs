//! Schema-aligned DTOs for interaction requests and responses.
//!
//! Aligned with workflow/interaction.schema.yaml (schema_version: 1).

use serde::{Deserialize, Serialize};

// ─── Shared enums ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum InteractionKind {
    ApprovalRequest,
    RestoreRequest,
    QuestionRequest,
    InputRequest,
    ConflictResolution,
    HandoffNotice,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum InteractionStatus {
    Pending,
    Answered,
    Cancelled,
    Expired,
    Failed,
    Superseded,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SelectionMode {
    Boolean,
    SingleSelect,
    MultiSelect,
    Text,
    Number,
    Path,
    Secret,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CommentMode {
    Disabled,
    Optional,
    Required,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PresentationMode {
    TuiMenu,
    TextMenu,
    PlainPrompt,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ColorProfile {
    Auto,
    Mono,
    Ansi16,
    Ansi256,
    Rgb24,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RiskLevel {
    Low,
    Medium,
    High,
    Critical,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResponseStatus {
    Completed,
    Cancelled,
    TimedOut,
    Error,
}

// ─── Request DTOs ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InteractionOption {
    pub id: String,
    pub label: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(default)]
    pub recommended: bool,
    #[serde(default)]
    pub destructive: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub shortcut: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PresentationHints {
    pub mode: PresentationMode,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub color_profile: Option<ColorProfile>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub theme: Option<String>,
}

/// Interaction request envelope — schema_version 1.
/// Required fields match workflow/interaction.schema.yaml request_envelope.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InteractionRequest {
    /// Must be 1
    pub schema: u32,
    pub interaction_id: String,
    pub kind: InteractionKind,
    pub status: InteractionStatus,
    pub title: String,
    pub message: String,
    pub selection_mode: SelectionMode,
    pub options: Vec<InteractionOption>,
    pub comment_mode: CommentMode,
    pub presentation: PresentationHints,
    pub originating_request_id: String,
    pub created_at: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub risk_level: Option<RiskLevel>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub timeout_seconds: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub scope: Option<String>,
}

// ─── Response DTOs ─────────────────────────────────────────────────────────

/// Interaction response envelope — schema_version 1.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InteractionResponse {
    /// Must be 1
    pub schema: u32,
    pub interaction_id: String,
    pub status: ResponseStatus,
    pub selected_option_ids: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub comment: Option<String>,
    pub responded_at: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub presenter_mode_used: Option<String>,
}

impl InteractionResponse {
    pub fn new(interaction_id: impl Into<String>, status: ResponseStatus) -> Self {
        Self {
            schema: 1,
            interaction_id: interaction_id.into(),
            status,
            selected_option_ids: Vec::new(),
            comment: None,
            responded_at: chrono::Utc::now().to_rfc3339(),
            presenter_mode_used: None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_request() -> InteractionRequest {
        InteractionRequest {
            schema: 1,
            interaction_id: "ix-20260318-001".to_string(),
            kind: InteractionKind::ApprovalRequest,
            status: InteractionStatus::Pending,
            title: "高风险写入确认".to_string(),
            message: "即将覆盖 workflow/*.yaml".to_string(),
            selection_mode: SelectionMode::SingleSelect,
            options: vec![
                InteractionOption {
                    id: "approve_once".to_string(),
                    label: "确认继续".to_string(),
                    description: None,
                    recommended: true,
                    destructive: false,
                    shortcut: Some("y".to_string()),
                },
                InteractionOption {
                    id: "deny".to_string(),
                    label: "拒绝".to_string(),
                    description: None,
                    recommended: false,
                    destructive: false,
                    shortcut: Some("n".to_string()),
                },
            ],
            comment_mode: CommentMode::Optional,
            presentation: PresentationHints {
                mode: PresentationMode::TextMenu,
                color_profile: Some(ColorProfile::Auto),
                theme: None,
            },
            originating_request_id: "req-123".to_string(),
            created_at: "2026-03-18T00:00:00Z".to_string(),
            risk_level: Some(RiskLevel::High),
            timeout_seconds: None,
            scope: None,
        }
    }

    #[test]
    fn test_request_roundtrip() {
        let req = sample_request();
        let json = serde_json::to_string(&req).expect("serialize request");
        let decoded: InteractionRequest = serde_json::from_str(&json).expect("deserialize request");
        assert_eq!(req, decoded);
    }

    #[test]
    fn test_response_roundtrip() {
        let mut resp = InteractionResponse::new("ix-20260318-001", ResponseStatus::Completed);
        resp.selected_option_ids = vec!["approve_once".to_string()];
        resp.comment = Some("Looks good".to_string());
        resp.presenter_mode_used = Some("text_menu".to_string());

        let json = serde_json::to_string(&resp).expect("serialize response");
        let decoded: InteractionResponse = serde_json::from_str(&json).expect("deserialize response");
        assert_eq!(resp.schema, decoded.schema);
        assert_eq!(resp.interaction_id, decoded.interaction_id);
        assert_eq!(resp.selected_option_ids, decoded.selected_option_ids);
        assert_eq!(resp.comment, decoded.comment);
    }

    #[test]
    fn test_schema_version_is_1() {
        let req = sample_request();
        assert_eq!(req.schema, 1);
        let resp = InteractionResponse::new("ix-test-001", ResponseStatus::Cancelled);
        assert_eq!(resp.schema, 1);
    }

    #[test]
    fn test_request_fields_present_in_json() {
        let req = sample_request();
        let json = serde_json::to_string(&req).unwrap();
        assert!(json.contains("interaction_id"));
        assert!(json.contains("ix-20260318-001"));
        assert!(json.contains("selection_mode"));
        assert!(json.contains("originating_request_id"));
        assert!(json.contains("comment_mode"));
        assert!(json.contains("presentation"));
    }

    #[test]
    fn test_optional_fields_omitted_when_none() {
        let resp = InteractionResponse::new("ix-test-002", ResponseStatus::Completed);
        let json = serde_json::to_string(&resp).unwrap();
        // comment and presenter_mode_used should be absent when None
        assert!(!json.contains("\"comment\""));
        assert!(!json.contains("presenter_mode_used"));
    }
}
