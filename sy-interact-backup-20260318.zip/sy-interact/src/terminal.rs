//! Terminal capability probing for sy-interact.
//!
//! Detects TTY status, color depth, and terminal dimensions.
//! All output goes to stderr — stdout is reserved for structured data.

use crossterm::tty::IsTty;

/// Color depth supported by the terminal.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[cfg_attr(test, derive(PartialOrd, Ord))]
#[serde(rename_all = "snake_case")]
pub enum ColorDepth {
    /// No color support (plain text only)
    Mono,
    /// 16 ANSI colors
    Ansi16,
    /// 256-color palette
    Ansi256,
    /// 24-bit true color
    TrueColor,
}

use serde::{Deserialize, Serialize};

/// Capabilities detected from the current terminal environment.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TerminalCapabilities {
    pub is_tty: bool,
    pub color_depth: ColorDepth,
    pub columns: u16,
    pub rows: u16,
    pub ansi_enabled: bool,
    pub supports_raw_mode: bool,
    pub supports_alternate_screen: bool,
    /// Recommended presentation mode given detected capabilities.
    pub preferred_mode: String,
}

/// Probe the current terminal and return detected capabilities.
pub fn probe_terminal() -> TerminalCapabilities {
    let is_tty = std::io::stderr().is_tty();

    let (columns, rows) = if is_tty {
        crossterm::terminal::size().unwrap_or((80, 24))
    } else {
        (80, 24)
    };

    let color_depth = detect_color_depth(is_tty);
    let ansi_enabled = is_tty && color_depth != ColorDepth::Mono;

    // On Windows, raw mode requires a real console handle.
    let supports_raw_mode = is_tty && probe_raw_mode();
    // Alternate screen requires raw mode support.
    let supports_alternate_screen = supports_raw_mode;

    let preferred_mode = if !is_tty {
        "plain".to_string()
    } else if supports_raw_mode {
        "tui".to_string()
    } else {
        "text".to_string()
    };

    TerminalCapabilities {
        is_tty,
        color_depth,
        columns,
        rows,
        ansi_enabled,
        supports_raw_mode,
        supports_alternate_screen,
        preferred_mode,
    }
}

/// Detect color depth from environment variables.
fn detect_color_depth(is_tty: bool) -> ColorDepth {
    if !is_tty {
        return ColorDepth::Mono;
    }

    // COLORTERM=truecolor or 24bit → TrueColor
    if let Ok(val) = std::env::var("COLORTERM") {
        let val = val.to_lowercase();
        if val == "truecolor" || val == "24bit" {
            return ColorDepth::TrueColor;
        }
    }

    // TERM=xterm-256color or similar → Ansi256
    if let Ok(term) = std::env::var("TERM") {
        if term.contains("256color") {
            return ColorDepth::Ansi256;
        }
        if term.starts_with("xterm") || term.starts_with("screen") || term.starts_with("vt") {
            return ColorDepth::Ansi16;
        }
    }

    // Windows: if VT processing works (crossterm enables it), treat as Ansi256 minimum
    #[cfg(windows)]
    {
        return ColorDepth::Ansi256;
    }

    #[cfg(not(windows))]
    ColorDepth::Ansi16
}

/// Try enabling raw mode and immediately disable it to check support.
fn probe_raw_mode() -> bool {
    match crossterm::terminal::enable_raw_mode() {
        Ok(_) => {
            let _ = crossterm::terminal::disable_raw_mode();
            true
        }
        Err(_) => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_probe_terminal_returns_valid_struct() {
        let caps = probe_terminal();
        // columns and rows must be > 0
        assert!(caps.columns > 0, "columns should be > 0, got {}", caps.columns);
        assert!(caps.rows > 0, "rows should be > 0, got {}", caps.rows);
        // preferred_mode must be one of the known values
        assert!(
            ["tui", "text", "plain"].contains(&caps.preferred_mode.as_str()),
            "unexpected preferred_mode: {}",
            caps.preferred_mode
        );
    }

    #[test]
    fn test_probe_terminal_is_tty_false_gives_mono_and_plain() {
        // In CI / non-TTY environments this is guaranteed
        let caps = probe_terminal();
        if !caps.is_tty {
            assert_eq!(caps.color_depth, ColorDepth::Mono);
            assert_eq!(caps.preferred_mode, "plain");
            assert!(!caps.ansi_enabled);
        }
        // If is_tty, we just verify the struct is coherent
    }

    #[test]
    fn test_color_depth_serialization() {
        let depths = [
            ColorDepth::Mono,
            ColorDepth::Ansi16,
            ColorDepth::Ansi256,
            ColorDepth::TrueColor,
        ];
        for depth in &depths {
            let json = serde_json::to_string(depth).unwrap();
            let decoded: ColorDepth = serde_json::from_str(&json).unwrap();
            assert_eq!(depth, &decoded);
        }
    }

    #[test]
    fn test_terminal_capabilities_serialization() {
        let caps = probe_terminal();
        let json = serde_json::to_string(&caps).unwrap();
        let decoded: TerminalCapabilities = serde_json::from_str(&json).unwrap();
        assert_eq!(caps.is_tty, decoded.is_tty);
        assert_eq!(caps.columns, decoded.columns);
        assert_eq!(caps.preferred_mode, decoded.preferred_mode);
    }

    #[test]
    fn test_ansi_enabled_false_when_no_tty() {
        let caps = probe_terminal();
        if !caps.is_tty {
            assert!(!caps.ansi_enabled, "ansi_enabled must be false when not a TTY");
        }
    }
}
