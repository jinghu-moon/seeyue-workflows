//! File I/O for interaction request and response files.
//!
//! Requests and responses are stored as JSON files under .ai/workflow/interactions/.
//! See docs/interaction-runtime-integration.md for the directory layout.

use std::path::Path;
use crate::schema::{InteractionRequest, InteractionResponse};

/// Read an InteractionRequest from a JSON file.
pub fn read_request(path: &Path) -> Result<InteractionRequest, IoError> {
    let content = std::fs::read_to_string(path).map_err(|e| IoError::Io {
        path: path.to_string_lossy().into_owned(),
        message: e.to_string(),
    })?;
    serde_json::from_str(&content).map_err(|e| IoError::Parse {
        path: path.to_string_lossy().into_owned(),
        message: e.to_string(),
    })
}

/// Write an InteractionResponse to a JSON file.
/// Creates parent directories automatically.
pub fn write_response(path: &Path, response: &InteractionResponse) -> Result<(), IoError> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| IoError::Io {
            path: parent.to_string_lossy().into_owned(),
            message: e.to_string(),
        })?;
    }
    let content = serde_json::to_string_pretty(response).map_err(|e| IoError::Serialize {
        message: e.to_string(),
    })?;
    std::fs::write(path, content).map_err(|e| IoError::Io {
        path: path.to_string_lossy().into_owned(),
        message: e.to_string(),
    })
}

/// Errors from file I/O operations.
#[derive(Debug)]
pub enum IoError {
    Io { path: String, message: String },
    Parse { path: String, message: String },
    Serialize { message: String },
}

impl std::fmt::Display for IoError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IoError::Io { path, message } => write!(f, "IO error at {path}: {message}"),
            IoError::Parse { path, message } => write!(f, "Parse error at {path}: {message}"),
            IoError::Serialize { message } => write!(f, "Serialize error: {message}"),
        }
    }
}

impl std::error::Error for IoError {}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::schema::{
        ColorProfile, CommentMode, InteractionKind, InteractionOption, InteractionResponse,
        InteractionStatus, PresentationHints, PresentationMode, ResponseStatus, RiskLevel,
        SelectionMode,
    };
    use tempfile::tempdir;

    fn sample_request() -> InteractionRequest {
        InteractionRequest {
            schema: 1,
            interaction_id: "ix-20260318-001".to_string(),
            kind: InteractionKind::ApprovalRequest,
            status: InteractionStatus::Pending,
            title: "确认操作".to_string(),
            message: "测试消息".to_string(),
            selection_mode: SelectionMode::SingleSelect,
            options: vec![InteractionOption {
                id: "approve".to_string(),
                label: "确认".to_string(),
                description: None,
                recommended: true,
                destructive: false,
                shortcut: None,
            }],
            comment_mode: CommentMode::Optional,
            presentation: PresentationHints {
                mode: PresentationMode::TextMenu,
                color_profile: Some(ColorProfile::Auto),
                theme: None,
            },
            originating_request_id: "req-001".to_string(),
            created_at: "2026-03-18T00:00:00Z".to_string(),
            risk_level: Some(RiskLevel::High),
            timeout_seconds: None,
            scope: None,
        }
    }

    #[test]
    fn test_write_and_read_response_roundtrip() {
        let dir = tempdir().unwrap();
        let response_path = dir.path().join("response.json");

        let mut resp = InteractionResponse::new("ix-20260318-001", ResponseStatus::Completed);
        resp.selected_option_ids = vec!["approve".to_string()];

        write_response(&response_path, &resp).expect("write_response failed");
        assert!(response_path.exists(), "response file should exist after write");

        let content = std::fs::read_to_string(&response_path).unwrap();
        let decoded: InteractionResponse = serde_json::from_str(&content).unwrap();
        assert_eq!(resp.interaction_id, decoded.interaction_id);
        assert_eq!(resp.selected_option_ids, decoded.selected_option_ids);
    }

    #[test]
    fn test_read_request_from_file() {
        let dir = tempdir().unwrap();
        let req_path = dir.path().join("request.json");

        let req = sample_request();
        let json = serde_json::to_string_pretty(&req).unwrap();
        std::fs::write(&req_path, &json).unwrap();

        let loaded = read_request(&req_path).expect("read_request failed");
        assert_eq!(loaded.interaction_id, req.interaction_id);
        assert_eq!(loaded.schema, 1);
        assert_eq!(loaded.options.len(), 1);
    }

    #[test]
    fn test_read_request_missing_file_returns_error() {
        let result = read_request(Path::new("/nonexistent/ix-missing.json"));
        assert!(result.is_err(), "should fail on missing file");
        let msg = result.unwrap_err().to_string();
        assert!(msg.contains("IO error") || msg.contains("error"), "error message: {msg}");
    }

    #[test]
    fn test_write_response_creates_parent_dirs() {
        let dir = tempdir().unwrap();
        let nested = dir.path().join("a").join("b").join("resp.json");
        let resp = InteractionResponse::new("ix-test-003", ResponseStatus::Cancelled);
        write_response(&nested, &resp).expect("write_response with nested dirs failed");
        assert!(nested.exists());
    }
}
