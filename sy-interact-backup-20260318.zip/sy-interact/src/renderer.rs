//! Fallback renderers for sy-interact.
//!
//! Two renderers that do not require raw mode or alternate screen:
//! - `text_menu`: numbered list printed to stderr, reads line from stdin
//! - `plain_prompt`: simple y/n or free-text prompt to stderr, reads from stdin
//!
//! Both write display to stderr, read input from stdin.
//! Both return a TerminalResponse the caller converts to InteractionResponse.

use std::io::{BufRead, Write};
use crate::schema::{CommentMode, InteractionOption, InteractionRequest, ResponseStatus};

/// The result returned by a renderer.
#[derive(Debug, Clone, PartialEq)]
pub struct TerminalResponse {
    pub status: ResponseStatus,
    pub selected_option_ids: Vec<String>,
    pub comment: Option<String>,
    pub presenter_mode: String,
}

impl TerminalResponse {
    pub fn cancelled(presenter_mode: &str) -> Self {
        Self {
            status: ResponseStatus::Cancelled,
            selected_option_ids: Vec::new(),
            comment: None,
            presenter_mode: presenter_mode.to_string(),
        }
    }
}

/// Render a numbered text menu to stderr, read choice from stdin.
///
/// `stdin_lines` is injected for testing; pass `None` to read from real stdin.
pub fn text_menu<R: BufRead, W: Write>(
    request: &InteractionRequest,
    options: &[InteractionOption],
    stdin: &mut R,
    stderr: &mut W,
) -> TerminalResponse {
    // Print header
    writeln!(stderr, "\n[sy-interact] {}", request.title).ok();
    writeln!(stderr, "{}", request.message).ok();
    writeln!(stderr).ok();

    // Print numbered options
    for (i, opt) in options.iter().enumerate() {
        let rec = if opt.recommended { " (recommended)" } else { "" };
        let sc = opt.shortcut.as_deref().map(|s| format!(" [{}]", s)).unwrap_or_default();
        writeln!(stderr, "  {}){sc} {}{rec}", i + 1, opt.label).ok();
    }

    // Optional comment prompt
    let needs_comment = matches!(request.comment_mode, CommentMode::Required | CommentMode::Optional);

    writeln!(stderr).ok();
    write!(stderr, "Enter choice (1-{}): ", options.len()).ok();
    stderr.flush().ok();

    let mut line = String::new();
    if stdin.read_line(&mut line).is_err() || line.trim().is_empty() {
        return TerminalResponse::cancelled("text_menu");
    }
    let trimmed = line.trim();

    // Parse "q" or "cancel" as cancellation
    if trimmed.eq_ignore_ascii_case("q") || trimmed.eq_ignore_ascii_case("cancel") {
        return TerminalResponse::cancelled("text_menu");
    }

    let index: usize = match trimmed.parse::<usize>() {
        Ok(n) if n >= 1 && n <= options.len() => n - 1,
        _ => {
            writeln!(stderr, "Invalid choice.").ok();
            return TerminalResponse::cancelled("text_menu");
        }
    };

    let selected = &options[index];
    let selected_id = selected.id.clone();

    // Collect optional comment
    let comment = if needs_comment {
        let prompt = if matches!(request.comment_mode, CommentMode::Required) {
            "Comment (required): "
        } else {
            "Comment (optional, Enter to skip): "
        };
        write!(stderr, "{prompt}").ok();
        stderr.flush().ok();
        let mut c = String::new();
        stdin.read_line(&mut c).ok();
        let c = c.trim().to_string();
        if c.is_empty() { None } else { Some(c) }
    } else {
        None
    };

    TerminalResponse {
        status: ResponseStatus::Completed,
        selected_option_ids: vec![selected_id],
        comment,
        presenter_mode: "text_menu".to_string(),
    }
}

/// Render a simple y/n or free-text prompt to stderr.
pub fn plain_prompt<R: BufRead, W: Write>(
    request: &InteractionRequest,
    stdin: &mut R,
    stderr: &mut W,
) -> TerminalResponse {
    writeln!(stderr, "\n[sy-interact] {}", request.title).ok();
    writeln!(stderr, "{}", request.message).ok();

    // If there are options, show them as a simple list
    if !request.options.is_empty() {
        for opt in &request.options {
            let sc = opt.shortcut.as_deref().unwrap_or(&opt.id);
            writeln!(stderr, "  [{}] {}", sc, opt.label).ok();
        }
    }

    write!(stderr, "Your choice: ").ok();
    stderr.flush().ok();

    let mut line = String::new();
    if stdin.read_line(&mut line).is_err() || line.trim().is_empty() {
        return TerminalResponse::cancelled("plain_prompt");
    }
    let trimmed = line.trim().to_lowercase();

    if trimmed == "q" || trimmed == "cancel" || trimmed == "n" {
        return TerminalResponse::cancelled("plain_prompt");
    }

    // Match against option shortcuts or ids
    let selected_id = request.options.iter().find(|o| {
        o.shortcut.as_deref().map(|s| s.eq_ignore_ascii_case(&trimmed)).unwrap_or(false)
            || o.id.eq_ignore_ascii_case(&trimmed)
            || o.label.eq_ignore_ascii_case(&trimmed)
    }).map(|o| o.id.clone());

    match selected_id {
        Some(id) => TerminalResponse {
            status: ResponseStatus::Completed,
            selected_option_ids: vec![id],
            comment: None,
            presenter_mode: "plain_prompt".to_string(),
        },
        None => {
            // Treat raw input as free-text response (for text/input_request kinds)
            TerminalResponse {
                status: ResponseStatus::Completed,
                selected_option_ids: Vec::new(),
                comment: Some(trimmed.to_string()),
                presenter_mode: "plain_prompt".to_string(),
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::schema::{
        ColorProfile, CommentMode, InteractionKind, InteractionOption, InteractionStatus,
        PresentationHints, PresentationMode, RiskLevel, SelectionMode,
    };
    use std::io::Cursor;

    fn make_request(comment_mode: CommentMode) -> InteractionRequest {
        InteractionRequest {
            schema: 1,
            interaction_id: "ix-20260318-001".to_string(),
            kind: InteractionKind::ApprovalRequest,
            status: InteractionStatus::Pending,
            title: "确认操作".to_string(),
            message: "即将执行高风险写入".to_string(),
            selection_mode: SelectionMode::SingleSelect,
            options: vec![
                InteractionOption {
                    id: "approve".to_string(),
                    label: "确认".to_string(),
                    description: None,
                    recommended: true,
                    destructive: false,
                    shortcut: Some("y".to_string()),
                },
                InteractionOption {
                    id: "deny".to_string(),
                    label: "拒绝".to_string(),
                    description: None,
                    recommended: false,
                    destructive: false,
                    shortcut: Some("n".to_string()),
                },
            ],
            comment_mode,
            presentation: PresentationHints {
                mode: PresentationMode::TextMenu,
                color_profile: Some(ColorProfile::Auto),
                theme: None,
            },
            originating_request_id: "req-001".to_string(),
            created_at: "2026-03-18T00:00:00Z".to_string(),
            risk_level: Some(RiskLevel::High),
            timeout_seconds: None,
            scope: None,
        }
    }

    #[test]
    fn test_text_menu_selects_first_option() {
        let req = make_request(CommentMode::Disabled);
        let options = req.options.clone();
        let mut stdin = Cursor::new("1\n");
        let mut stderr_buf = Vec::new();
        let resp = text_menu(&req, &options, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Completed);
        assert_eq!(resp.selected_option_ids, vec!["approve"]);
        assert_eq!(resp.presenter_mode, "text_menu");
    }

    #[test]
    fn test_text_menu_selects_second_option() {
        let req = make_request(CommentMode::Disabled);
        let options = req.options.clone();
        let mut stdin = Cursor::new("2\n");
        let mut stderr_buf = Vec::new();
        let resp = text_menu(&req, &options, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Completed);
        assert_eq!(resp.selected_option_ids, vec!["deny"]);
    }

    #[test]
    fn test_text_menu_cancel_with_q() {
        let req = make_request(CommentMode::Disabled);
        let options = req.options.clone();
        let mut stdin = Cursor::new("q\n");
        let mut stderr_buf = Vec::new();
        let resp = text_menu(&req, &options, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Cancelled);
        assert!(resp.selected_option_ids.is_empty());
    }

    #[test]
    fn test_text_menu_invalid_choice_cancels() {
        let req = make_request(CommentMode::Disabled);
        let options = req.options.clone();
        let mut stdin = Cursor::new("99\n");
        let mut stderr_buf = Vec::new();
        let resp = text_menu(&req, &options, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Cancelled);
    }

    #[test]
    fn test_text_menu_with_optional_comment() {
        let req = make_request(CommentMode::Optional);
        let options = req.options.clone();
        // choice=1, then comment
        let mut stdin = Cursor::new("1\nLooks good\n");
        let mut stderr_buf = Vec::new();
        let resp = text_menu(&req, &options, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Completed);
        assert_eq!(resp.selected_option_ids, vec!["approve"]);
        assert_eq!(resp.comment, Some("Looks good".to_string()));
    }

    #[test]
    fn test_text_menu_optional_comment_skipped() {
        let req = make_request(CommentMode::Optional);
        let options = req.options.clone();
        // choice=1, empty comment (Enter)
        let mut stdin = Cursor::new("1\n\n");
        let mut stderr_buf = Vec::new();
        let resp = text_menu(&req, &options, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Completed);
        assert_eq!(resp.comment, None);
    }

    #[test]
    fn test_plain_prompt_matches_shortcut() {
        let req = make_request(CommentMode::Disabled);
        let mut stdin = Cursor::new("y\n");
        let mut stderr_buf = Vec::new();
        let resp = plain_prompt(&req, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Completed);
        assert_eq!(resp.selected_option_ids, vec!["approve"]);
        assert_eq!(resp.presenter_mode, "plain_prompt");
    }

    #[test]
    fn test_plain_prompt_cancel_with_n() {
        let req = make_request(CommentMode::Disabled);
        let mut stdin = Cursor::new("n\n");
        let mut stderr_buf = Vec::new();
        let resp = plain_prompt(&req, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Cancelled);
    }

    #[test]
    fn test_plain_prompt_empty_input_cancels() {
        let req = make_request(CommentMode::Disabled);
        let mut stdin = Cursor::new("");
        let mut stderr_buf = Vec::new();
        let resp = plain_prompt(&req, &mut stdin, &mut stderr_buf);
        assert_eq!(resp.status, ResponseStatus::Cancelled);
    }

    #[test]
    fn test_text_menu_output_contains_title() {
        let req = make_request(CommentMode::Disabled);
        let options = req.options.clone();
        let mut stdin = Cursor::new("1\n");
        let mut stderr_buf = Vec::new();
        text_menu(&req, &options, &mut stdin, &mut stderr_buf);
        let output = String::from_utf8_lossy(&stderr_buf);
        assert!(output.contains("确认操作"), "stderr should contain title");
        assert!(output.contains("确认"), "stderr should contain option label");
    }
}
